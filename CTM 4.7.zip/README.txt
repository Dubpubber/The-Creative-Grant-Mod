Hey! Thanks for downloading my mod!

Manual Installation process:
 1. Close Prison Architect (If open)
 2. Choose what type of mod you'd like.
  - NO PRICE MOD: Programs, research and materials no longer give YOU money.
  - PRICE MOD: Programs, research and materials remain the same price as vanilla game.
 3. Go into the mod type you choose folder.
 4. Copy the "CTM_Mod" folder inside to your clipboard. (Ctrl + C) (Right click + copy).
 5. Navigate to your known mods folder.
  - WINDOWS USERS:
    A. Navigate to your AppData folder. (C:\Users\MY-PC-NAME\AppData\Local)
	 - Replace MY-PC-NAME with the name of your user.
  - Mac/Linux:
    A. Open Prison Architect.
	B. Hit Escape and go to extras.
	C. Click, "Open Mods Folder".
  6. Now, paste the contents of your folder into the mods folder.
  7. Launch the game, you're done!